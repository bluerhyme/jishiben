import UIAbility from '@ohos.app.ability.UIAbility';
import window from '@ohos.window';
import { DBUtil } from '../util/DBUtil';
import { PassUtil } from '../util/PassUtil';

export default class EntryAbility extends UIAbility {
  onCreate(want, launchParam) {

  }

  onDestroy() {

  }

  async onWindowStageCreate(windowStage: window.WindowStage) {
    await PassUtil.init(this.context)
    await DBUtil.init(this.context)
    if (await PassUtil.hasPass()) {
      await windowStage.loadContent('pages/Login');
    }else{
      await windowStage.loadContent('pages/Index');
    }
  }

  onWindowStageDestroy() {

  }

  onForeground() {

  }

  onBackground() {

  }
}