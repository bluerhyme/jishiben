import relationalStore from '@ohos:data.relationalStore';
const table = "Note";
export class DBUtil {
    static async init(context) {
        DBUtil.store = await relationalStore.getRdbStore(context, {
            name: "note.db",
            securityLevel: relationalStore.SecurityLevel.S1
        });
        // 创建表
        await DBUtil.store.executeSql(`CREATE TABLE IF NOT EXISTS Note (id INTEGER PRIMARY KEY AUTOINCREMENT,title VARCHAR(255),content TEXT,crateTime DATE)`);
    }
    static async insertNote(note) {
        const valueBucket = Object.assign({}, note);
        await DBUtil.store.insert(table, valueBucket);
        DBUtil.store.commit();
    }
    static async updateNote(note) {
        const valueBucket = Object.assign({}, note);
        await DBUtil.store.update(valueBucket, new relationalStore.RdbPredicates(table).equalTo("id", note.id));
        DBUtil.store.commit();
    }
    static async queryNote() {
        const res = await DBUtil.store.query(new relationalStore.RdbPredicates(table));
        const arr = [];
        while (res.goToNextRow()) {
            arr.push({
                id: res.getLong(0),
                title: res.getString(1),
                content: res.getString(2),
                crateTime: res.getString(3)
            });
        }
        res.close();
        return arr;
    }
}
//# sourceMappingURL=DBUtil.js.map