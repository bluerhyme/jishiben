import router from '@ohos:router';
import prompt from '@ohos:promptAction';
import { PassUtil } from '@bundle:com.example.cnnmn123/entry/ets/util/PassUtil';
function __TextInput__InputStyle() {
    TextInput.width('100%');
    TextInput.height(45);
    TextInput.backgroundColor('#F1F3F5');
    TextInput.fontSize(45);
    TextInput.placeholderColor('#99182431');
    TextInput.margin({ top: 8 });
    TextInput.padding({ left: 10 });
}
function __Line__LineStyle() {
    Line.width('100%');
    Line.height(1);
    Line.backgroundColor(Color.Gray);
}
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__pass = new ObservedPropertySimplePU('', this, "pass");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.pass !== undefined) {
            this.pass = params.pass;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pass.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pass.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get pass() {
        return this.__pass.get();
    }
    set pass(newValue) {
        this.__pass.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //根组件
            Column.create();
            Column.debugLine("pages/Login.ets(31:5)");
            //根组件
            Column.width('100%');
            //根组件
            Column.height('100%');
            //根组件
            Column.backgroundColor('#F1F3F5');
            if (!isInitialRender) {
                //根组件
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //logo+标题载体
            Column.create();
            Column.debugLine("pages/Login.ets(35:7)");
            //logo+标题载体
            Column.width('100%');
            //logo+标题载体
            Column.height('30%');
            //logo+标题载体
            Column.margin({ top: 20 });
            if (!isInitialRender) {
                //logo+标题载体
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //logo
            Row.create();
            Row.debugLine("pages/Login.ets(38:9)");
            if (!isInitialRender) {
                //logo
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" });
            Image.debugLine("pages/Login.ets(39:11)");
            Image.width(100);
            Image.height(100);
            Image.margin({ top: 30 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //logo
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //文字
            Row.create();
            Row.debugLine("pages/Login.ets(45:9)");
            if (!isInitialRender) {
                //文字
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('登录界面');
            Text.debugLine("pages/Login.ets(46:11)");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 16 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //文字
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Login.ets(51:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('输入密码登录');
            Text.debugLine("pages/Login.ets(52:11)");
            Text.fontSize(20);
            Text.fontWeight(400);
            Text.margin(({ top: 12 }));
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        //logo+标题载体
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入框载体
            Column.create();
            Column.debugLine("pages/Login.ets(63:7)");
            //输入框载体
            Column.width('100%');
            //输入框载体
            Column.height('35%');
            //输入框载体
            Column.margin({ top: 20 });
            if (!isInitialRender) {
                //输入框载体
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 17 });
            Column.debugLine("pages/Login.ets(64:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: { "id": 16777225, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" } });
            TextInput.debugLine("pages/Login.ets(66:11)");
            __TextInput__InputStyle();
            TextInput.maxLength(8);
            TextInput.onChange((value) => {
                this.pass = value;
            });
            TextInput.type(InputType.Password);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Line.create();
            Line.debugLine("pages/Login.ets(73:11)");
            __Line__LineStyle();
            if (!isInitialRender) {
                Line.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        //输入框载体
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //按钮载体
            Column.create();
            Column.debugLine("pages/Login.ets(82:7)");
            //按钮载体
            Column.width('100%');
            //按钮载体
            Column.height('25%');
            if (!isInitialRender) {
                //按钮载体
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Login.ets(83:9)");
            Row.margin({ bottom: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('登录');
            Button.debugLine("pages/Login.ets(84:11)");
            Button.fontSize(20);
            Button.fontWeight(FontWeight.Bold);
            Button.fontColor(Color.White);
            Button.width('40%');
            Button.onClick(async () => {
                if (await PassUtil.getPass() === this.pass) {
                    router.replaceUrl({
                        url: 'pages/Home'
                    });
                }
                else {
                    prompt.showToast({
                        message: { "id": 16777229, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" }
                    });
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        //按钮载体
        Column.pop();
        //根组件
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new LoginPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Login.js.map