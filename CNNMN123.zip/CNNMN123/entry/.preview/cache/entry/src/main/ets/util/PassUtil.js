import preferences from '@ohos:data.preferences';
export class PassUtil {
    static async init(context) {
        PassUtil.pre = await preferences.getPreferences(context, "login_pass");
    }
    static async putPass(pass) {
        await PassUtil.pre.put("pass", pass);
        await PassUtil.pre.flush();
    }
    static async hasPass() {
        return await PassUtil.pre.has("pass");
    }
    static async getPass() {
        return (await PassUtil.pre.get("pass", null));
    }
}
//# sourceMappingURL=PassUtil.js.map