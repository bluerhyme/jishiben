import router from '@ohos:router';
import promptAction from '@ohos:promptAction';
import { PassUtil } from '@bundle:com.example.cnnmn123/entry/ets/util/PassUtil';
function __TextInput__InputStyle() {
    TextInput.width('100%');
    TextInput.height(45);
    TextInput.backgroundColor('#F1F3F5');
    TextInput.fontSize(45);
    TextInput.placeholderColor('#99182431');
    TextInput.margin({ top: 8 });
    TextInput.padding({ left: 10 });
}
function __Line__LineStyle() {
    Line.width('100%');
    Line.height(1);
    Line.backgroundColor(Color.Gray);
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__passf = new ObservedPropertySimplePU("", this, "passf");
        this.__passs = new ObservedPropertySimplePU("", this, "passs");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.passf !== undefined) {
            this.passf = params.passf;
        }
        if (params.passs !== undefined) {
            this.passs = params.passs;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__passf.purgeDependencyOnElmtId(rmElmtId);
        this.__passs.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__passf.aboutToBeDeleted();
        this.__passs.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get passf() {
        return this.__passf.get();
    }
    set passf(newValue) {
        this.__passf.set(newValue);
    }
    get passs() {
        return this.__passs.get();
    }
    set passs(newValue) {
        this.__passs.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 18 });
            Column.debugLine("pages/Index.ets(26:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F3F5');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //logo载体
            Column.create();
            Column.debugLine("pages/Index.ets(29:7)");
            //logo载体
            Column.width('100%');
            //logo载体
            Column.height('30%');
            //logo载体
            Column.margin({ top: 20 });
            if (!isInitialRender) {
                //logo载体
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(30:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(31:11)");
            Image.width(100);
            Image.height(100);
            Image.margin({ top: 30 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(37:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777234, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" });
            Text.debugLine("pages/Index.ets(38:11)");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 16 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        //logo载体
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入框载体
            Column.create();
            Column.debugLine("pages/Index.ets(49:7)");
            //输入框载体
            Column.width('100%');
            //输入框载体
            Column.height('35%');
            if (!isInitialRender) {
                //输入框载体
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 17 });
            Column.debugLine("pages/Index.ets(50:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: { "id": 16777225, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" } });
            TextInput.debugLine("pages/Index.ets(51:11)");
            __TextInput__InputStyle();
            TextInput.maxLength(8);
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.passf = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Line.create();
            Line.debugLine("pages/Index.ets(58:11)");
            __Line__LineStyle();
            if (!isInitialRender) {
                Line.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: { "id": 16777222, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" } });
            TextInput.debugLine("pages/Index.ets(61:11)");
            __TextInput__InputStyle();
            TextInput.maxLength(8);
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.passs = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Line.create();
            Line.debugLine("pages/Index.ets(68:11)");
            __Line__LineStyle();
            if (!isInitialRender) {
                Line.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        //输入框载体
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //注册按钮
            Column.create();
            Column.debugLine("pages/Index.ets(76:7)");
            //注册按钮
            Column.width('100%');
            //注册按钮
            Column.height('25%');
            if (!isInitialRender) {
                //注册按钮
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(77:9)");
            Row.margin({ bottom: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ "id": 16777233, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" });
            Button.debugLine("pages/Index.ets(78:11)");
            Button.fontSize(20);
            Button.fontWeight(FontWeight.Bold);
            Button.fontColor(Color.White);
            Button.width('40%');
            Button.onClick(async () => {
                if (this.passf !== this.passs) {
                    promptAction.showToast({
                        message: { "id": 16777231, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" }
                    });
                }
                else if (!this.passf || !this.passs) {
                    promptAction.showToast({
                        message: { "id": 16777232, "type": 10003, params: [], "bundleName": "com.example.cnnmn123", "moduleName": "entry" }
                    });
                }
                else if (this.passf === this.passs) {
                    // 写入首选项
                    await PassUtil.putPass(this.passf);
                    await router.replaceUrl({
                        url: 'pages/Home'
                    });
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        //注册按钮
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map