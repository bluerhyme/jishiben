import UIAbility from '@ohos:app.ability.UIAbility';
import { DBUtil } from '@bundle:com.example.cnnmn123/entry/ets/util/DBUtil';
import { PassUtil } from '@bundle:com.example.cnnmn123/entry/ets/util/PassUtil';
export default class EntryAbility extends UIAbility {
    onCreate(want, launchParam) {
    }
    onDestroy() {
    }
    async onWindowStageCreate(windowStage) {
        await PassUtil.init(this.context);
        await DBUtil.init(this.context);
        if (await PassUtil.hasPass()) {
            await windowStage.loadContent('pages/Login');
        }
        else {
            await windowStage.loadContent('pages/Index');
        }
    }
    onWindowStageDestroy() {
    }
    onForeground() {
    }
    onBackground() {
    }
}
//# sourceMappingURL=EntryAbility.js.map